const Discord = require('discord.js');
const client = new Discord.Client();
const ayarlar = require('./ayarlar.json');
const fs = require('fs');
const moment = require('moment');
require('./util/eventLoader')(client);

var prefix = ayarlar.prefix;

const log = message => {
  console.log(`[${moment().format('YYYY-MM-DD HH:mm:ss')}] ${message}`);
};

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir('./komutlar/', (err, files) => {
  if (err) console.error(err);
  log(`${files.length} komut yüklenecek.`);
  files.forEach(f => {
    let props = require(`./komutlar/${f}`);
    log(`Yüklenen komut: ${props.help.name}.`);
    client.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      client.aliases.set(alias, props.help.name);
    });
  });
});

client.reload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e){
      reject(e);
    }
  });
};

client.on('guildBanAdd' , (guild, user) => {
  let aramızakatılanlar = guild.channels.find('name', 'aramıza-katılanlar');
  if (!aramızakatılanlar) return;
  aramızakatılanlar.send('https://media.giphy.com/media/8njotXALXXNrW/giphy.gif **Adalet dağıtma zamanı gelmiş!** '+ user.username +'**Bakıyorum da suç işlemiş,Yargı dağıtmaya devam** :fist: :writing_hand:  :spy:' );
});

client.load = command => {
  return new Promise((resolve, reject) => {
    try {
      let cmd = require(`./komutlar/${command}`);
      client.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        client.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e){
      reject(e);
    }
  });
};

client.unload = command => {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./komutlar/${command}`)];
      let cmd = require(`./komutlar/${command}`);
      client.commands.delete(command);
      client.aliases.forEach((cmd, alias) => {
        if (cmd === command) client.aliases.delete(alias);
      });
      resolve();
    } catch (e){
      reject(e);
    }
  });
};

client.on('message', msg => {
  if (msg.content.toLowerCase() === 'KEC™ | YouTube®') {
      message.channel.send('✅ **Resmi KEC™ | YouTube® sunucusuna hoşgeldin!**');
}
});

client.elevation = message => {
  if(!message.guild) {
	return; }
  let permlvl = 0;
  if (message.member.hasPermission("BAN_MEMBERS")) permlvl = 2;
  if (message.member.hasPermission("ADMINISTRATOR")) permlvl = 3;
  if (message.author.id === ayarlar.sahip) permlvl = 4;
  return permlvl;
};

var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;

client.on('warn', e => {
  console.log(chalk.bgYellow(e.replace(regToken, 'that was redacted')));
});

client.on('error', e => {
  console.log(chalk.bgRed(e.replace(regToken, 'that was redacted')));
});

client.login(ayarlar.token);

const { MessageEmbed } = require("discord.js");
const dbuttons = require("discord-buttons");
dbuttons(client);
const { MessageMenu, MessageMenuOption } = require('discord-buttons');
client.on("message", async message => {
    if(message.content.startsWith("kec!website-bilgi")) {
        if(message.author.bot) return;
        let secenek1 = new MessageMenuOption()
        .setLabel("WebSite Adresi")
        .setValue("1")
        .setDescription("Website Adresini Paylaşır..")
        .setDefault()
        .setEmoji("❔")
        let secenek2 = new MessageMenuOption()
        .setLabel("")
        .setValue("LIKEAT")
        .setDescription("Videoya like at.")
        .setDefault()
        .setEmoji("🔵")
        let secenek3 = new MessageMenuOption()
        .setLabel("Bildirimleri Aç")
        .setValue("BILDIRIM")
        .setDescription("Kanalımın bildirimlerini aç.")
        .setDefault()
        .setEmoji("🟡")
        let secenek4 = new MessageMenuOption()
        .setLabel("Yorum Yap")
        .setValue("YORUMYAP")
        .setDescription("Videoya yorum yap.")
        .setDefault()
        .setEmoji("⚪")
        let secenek5 = new MessageMenuOption()
        .setLabel("Sen Kralsın")
        .setValue("KRALSIN")
        .setDescription("Kralsın krall <3")
        .setDefault()
        .setEmoji("👑")
        let menu = new MessageMenu()
        .setID("MENU")
        .setMaxValues(1)
        .setMinValues(1)
        .setPlaceholder("Bana tıkla ve bişeye bas ._.")
        .addOption(secenek1)
        .addOption(secenek2)
        .addOption(secenek3)
        .addOption(secenek4)
        .addOption(secenek5)
        const embed = new MessageEmbed()
        .setTitle("Menü mü?!")
        .setDescription("Evet menü. Birini seç.")
        .setFooter("tanisalim mi")
        .setColor("BLUE")
        .setTimestamp()
        let menumesaj = await message.channel.send(embed, menu)
        function menuselection(menu) {
            switch(menu.values[0]) {
                case "ABONEOL":
                    menu.reply.send("Anaaa abone oldun mu, harika !!!", true)
                break;
                case "LIKEAT":
                    menu.reply.send("Layk şelalesiiiiiiiii", true)
                break;
                case "BILDIRIM":
                    menu.reply.send("Video yayınlanınca direk koş ha, anlamı kalmaz yoksa :P", true)
                break;
                case "YORUMYAP":
                    menu.reply.send("Yorumunu okicam, söz :D", true)
                break;
                case "KRALSIN":
                    menu.reply.send("Yalan yok, kralsın <3", true)
                break;
            }
        }
        client.on("clickMenu", menu => {
            if(menu.message.id == menumesaj.id) {
                if(menu.clicker.id == message.author.id) {
                    menuselection(menu)
                }else{
                    menu.reply.send("Menü sahibi değilsin.", true)
                }
            }
        })
    }
})
